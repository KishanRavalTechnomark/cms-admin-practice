export type OrganizationsType = {
    srNo?: number;
    id: number;
    name: string;
    active: boolean;
    prefix: string;
}
