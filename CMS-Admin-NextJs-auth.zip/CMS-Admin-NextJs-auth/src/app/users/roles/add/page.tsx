"use client";
import RolesForm from "../RolesForm";

const ADD_ROLE = -1;

const page = () => {
  return <RolesForm open={ADD_ROLE} />;
};

export default page;
