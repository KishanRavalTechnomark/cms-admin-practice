export default function Page() {
    return <h1>Blogs page!</h1>
  }
  