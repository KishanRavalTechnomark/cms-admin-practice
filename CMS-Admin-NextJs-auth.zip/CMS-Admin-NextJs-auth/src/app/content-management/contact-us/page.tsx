export default function Page() {
    return <h1>Contact Us page!</h1>
  }
  