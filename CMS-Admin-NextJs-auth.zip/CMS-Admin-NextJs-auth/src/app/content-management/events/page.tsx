export default function Page() {
    return <h1>Events page!</h1>
}
  