export default function Page() {
    return <h1>Popup!</h1>
}
  