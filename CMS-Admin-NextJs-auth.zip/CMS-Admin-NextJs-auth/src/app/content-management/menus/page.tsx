export default function Page() {
    return <h1>Menus page!</h1>
}
  