import TemplateListTable from "./TemplateListTable";

const page = () => {
  return (
    <>
      <TemplateListTable
      />
    </>
  );
};

export default page;
