import OrganizationsListTable from "./OrganizationsListTable";

const page = () => {
  return (
    <>
      <OrganizationsListTable />
    </>
  );
};

export default page;
