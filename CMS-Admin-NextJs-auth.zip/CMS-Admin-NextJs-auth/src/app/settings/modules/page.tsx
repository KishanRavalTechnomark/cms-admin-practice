export default function Page() {
    return <h1>Modules page!</h1>
}
  