export const template = {
  list: `template/list`,
  create: `template/create`,
  update: `template/update`,
  getById: `template/getById`,
  delete: `template/delete`,
  active: `template/active`,
  save: `template/save`,
  getTemplateSectionsById: `template/getTemplateSectionsById`,
};
