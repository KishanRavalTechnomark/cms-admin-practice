export const organization = {
  list: `organization/list`,
  create: `organization/create`,
  update: `organization/update`,
  getById: `organization/getById`,
  delete: `organization/delete`,
  active: `organization/active`,
};
