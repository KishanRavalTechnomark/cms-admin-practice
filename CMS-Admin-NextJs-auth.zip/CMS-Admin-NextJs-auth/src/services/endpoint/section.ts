export const section = {
  list: `section/list`,
  create: `section/create`,
  update: `section/update`,
  getById: `section/getById`,
  delete: `section/delete`,
  active: `section/active`,
};
