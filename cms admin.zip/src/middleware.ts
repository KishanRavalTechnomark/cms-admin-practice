// middleware.ts
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { getToken } from 'next-auth/jwt';

export async function middleware(req: NextRequest) {
  const token = await getToken({ req, secret: process.env.AUTH_SECRET });
  const { pathname } = req.nextUrl;

  // Allow the request if the following is true:
  // 1. The request is for the login page.
  // 2. The request has a token (meaning the user is authenticated).
  if (pathname.startsWith('/login') || token) {
    return NextResponse.next();
    // const url = req.nextUrl.clone();
    // url.pathname = '/home';
    // return NextResponse.redirect(url);
  }

  // Redirect to login if not authenticated and trying to access a protected route
  if (!token && pathname !== '/login') {
    const url = req.nextUrl.clone();
    url.pathname = '/login';
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

// Define middleware routes for specific paths if needed
export const config = {
  matcher: ['/home/:path*', '/profile/:path*', '/dashboard/:path*'], // Adjust these paths as needed
};
