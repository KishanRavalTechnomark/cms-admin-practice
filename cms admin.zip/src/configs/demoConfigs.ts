import type { Settings } from '@core/contexts/settingsContext'

const demoConfigs: { [key: string]: Settings } = {
  
}

export default demoConfigs
