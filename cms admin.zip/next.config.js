/** @type {import('next').NextConfig} */
const nextConfig = {
  basePath: process.env.BASEPATH || '', // Default to an empty string if BASEPATH is not set

  reactStrictMode: false,
};

module.exports = nextConfig;
