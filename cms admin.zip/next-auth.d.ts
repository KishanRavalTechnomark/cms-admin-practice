import NextAuth, { type DefaultSession } from "next-auth";

export type ExtendedUser = DefaultSession["user"] & {
  id: string;
  name: string;
  email: string;
  access_token: string;
  refresh_token: string;
  tokenExpiry: string;
  refreshTokenExpiry: number;
};

declare module "next-auth" {
  interface Session {
    user: ExtendedUser;
  }
}
